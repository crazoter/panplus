/**
 * @file This is basically main(...){}
 * @global
 */
(() => {
    App = {};
    //Wait for page load
    MutationObserver = window.MutationObserver || window.WebKitMutationObserver;
    var observer = new MutationObserver(function(mutations, observer) {
        //Check if DOM has been loaded
        if (mutations.length > 200 
            || (document.querySelector('header[role="banner"]') !== null && document.querySelector('header[role="banner"]').children[0].style.display !== "none")) {
            observer.disconnect();
            //Put initialization code here
            console.log("DOM loaded!");
            //Initialize cache & settings
            Cache.init().then(() => {
                Settings.init().then(() => {
                    let settings = Settings.getDataAsObject();
                    //debugger;
                    //Initialize app
                    App = {
                        sidebar: new Sidebar(settings),
                        speedSlider: new SpeedSlider(settings),
                        volumeBooster: new VolumeBooster(settings),
                        transcriptDisplay: new TranscriptDisplay(settings),
                        silenceCueManager: new SilenceCueManager(settings),
                        tsTracker: new TSTracker(settings),
                        carouselManager: new CarouselManager(settings),
                        //loggerDisabler: new LoggerDisabler(settings),
                        delayDisabler: new DelayDisabler(settings)
                    };

                    //Initialize initial settings
                    console.log("FIN");
                    $.notify("If there is an issue with silence trimming, please disable / configure in the settings tab.","info");
                });
            });
        }
    });
    observer.observe(document, {subtree: true, attributes: true});
})();